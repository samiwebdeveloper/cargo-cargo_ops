<!-- START FOOTER -->
        <div class="container-fluid container-fixed-lg footer no-print" >
          <div class="copyright sm-text-center">
            <p class="small no-margin pull-left sm-pull-reset">
              <span class="hint-text">Copyright © 2020</span>
              <span class="font-montserrat">T.M Group of Companies</span>.
              <span class="hint-text">All rights reserved. Powered By Atta Son's(Saim Tech)</span>
              
            </p>
          
            <div class="clearfix"></div>
          </div>
        </div>
        <!-- END FOOTER -->
      </div>
      <!-- END PAGE CONTENT WRAPPER -->
    </div>
    <!-- END PAGE CONTAINER -->
   
 
        </div>
        <!-- END Overlay Header !-->
        <div class="container-fluid">
         
        </div>
    
    <!-- BEGIN VENDOR JS -->
        <!-- BEGIN VENDOR JS -->
    <script src="<?php echo base_url();?>assets/plugins/pace/pace.min.js" type="text/javascript"></script>
	<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script> -->
   
	  <script src="<?php echo base_url();?>assets/jquery.table2excel.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/plugins/jquery/jquery-3.2.1.min.js" type="text/javascript"></script>
       <script src="<?php echo base_url();?>assets/jquery.inputmask.bundle.js" type="text/javascript"></script>
     <script src="<?php echo base_url(); ?>assets/datatables/datatables.min.js"></script>
     <script src="<?php echo base_url(); ?>assets/chartjs/Chart.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/datatables/buttons.colVis.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/datatables/buttons.print.min.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/modernizr.custom.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/plugins/jquery-ui/jquery-ui.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/plugins/popper/umd/popper.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/plugins/jquery/jquery-easy.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/plugins/jquery-ios-list/jquery.ioslist.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/plugins/jquery-actual/jquery.actual.min.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js"></script>
          <script src="<?php echo base_url();?>assets/plugins/select2/js/select2.min.js"></script>

    <!-- END VENDOR JS -->
    <!-- BEGIN CORE TEMPLATE JS -->
    <script src="<?php echo base_url();?>assets/pages/js/pages.min.js" type="text/javascript"></script>
    <!-- END CORE TEMPLATE JS -->
    <!-- BEGIN PAGE LEVEL JS -->
               <!--  <script src="<?php echo base_url();?>assets/plugins/charts.js" type="text/javascript"></script>-->
    <script src="<?php echo base_url();?>assets/js/scripts.js" type="text/javascript"></script>

    <!-- END PAGE LEVEL JS -->
    <!-- Search -->
    <script src="<?php echo base_url(); ?>assets/search.js"></script>
 <script src="<?php echo base_url();?>assets/multi.js"></script>
  </body>
</html>