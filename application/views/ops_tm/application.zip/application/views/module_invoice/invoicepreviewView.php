<?php
error_reporting(0);
$this->load->view('inc/header');
?>


 <!-- START PAGE CONTENT WRAPPER -->
      <div class="page-content-wrapper">
        <!-- START PAGE CONTENT -->
        <div class="content">
          <!-- START JUMBOTRON -->
          
          <!-- END JUMBOTRON -->
          <!-- START CONTAINER FLUID -->
          <div class="container-fluid container-fixed-lg">
            <!-- BEGIN PlACE PAGE CONTENT HERE -->
<div class="pgn-wrapper" data-position="top" style="top: 48px;" id="msg_div"></div>
<div class="row">
   
           

                  <div class="col-xl-12 col-lg-12" >

                <!-- START card -->
               
                    
               <div class=" container-fluid   container-fixed-lg bg-gray"  >
<div class="row">
<?php 
$sheet_code="";
$sheet_date="";
$sheet_rider="";
$sheet_rider_name="";
$sheet_route="";
$sheet_customer_name="";
$sheet_type="";
$sheet_payment="";
$sheet_tid="";
$total_fuel="";
$total_sp="";
$total_cash="";
$total_sc="";
$total_gst="";
$total_flyer="";
$sheet_id="";
$bulk_flyer="";
$osa_amount="";
$other_amount="";
$net_cod="";
$remark="";
if(!empty($sheet_data)){
foreach($sheet_data as $rows){
$sheet_code     = $rows->invoice_code;
$bulk_flyer     = $rows->bulk_flyer_amount;
$osa_amount     = $rows->osa_amount;
$other_amount     = $rows->other_amount;
$sheet_id       = $rows->invoice_id;
$sheet_date       = $rows->invoice_date;
$origin           = $rows->city_name;
$sheet_customer_name  =$rows->customer_name;
$sheet_type  =$rows->invoice_permission;
$sheet_payment  =$rows->payment_mode;
$sheet_tid  =$rows->payment_tid;
$total_cod  =$rows->invoice_amount;
$total_sc   =$rows->invoice_sc;
$total_gst  =$rows->invoice_gst;
$total_fuel =$rows->invoice_fuel;
$total_flyer =$rows->invoice_flyer;
$total_sp   =$rows->invoice_sp_handling;
$total_cash = $rows->invoice_cash_handling;
$remark     =$rows->invoice_remark;
}} ?>
<div class="col-md-12">
  <div class="card m-t-10">
              <div class="card-header  separator">
                        <div class="card-title">
                          <center>Invoice  <img src="<?php echo base_url(); ?>assets/barcode/invoice/<?php echo $sheet_code; ?>.png" width="100" height="50"></center>

                        </div>
                      </div>
                      <div class="card-body">
                       

 
<table width=30% border=1>
 <thead>
  <tr>
  <th><center>Sheet Code</center></th>
  <td><center><?php echo $sheet_code; ?></center></td>
  </tr> 
  <tr>
  <th><center>Date & Time</center></th>
  <td><center><?php echo $sheet_date; ?></center></td>
  </tr> 
<tr>
  <th><center>Customer</center></th>
  <td><center><?php echo $sheet_customer_name; ?></center></td>
  </tr> 
  <tr>
  <th><center>Without Flyer</center></th>
  <td><center><?php echo number_format($net_cod=$total_cod-($total_sc+$total_gst+$total_cash+$total_fuel+$total_sp)); ?>/-</center></td>
  </tr> 
  <tr>
  <th><center>Flyer Charges (-)</center></th>
  <td><center><?php echo $bulk_flyer; ?></center></td>
  </tr> 
  <tr>
  <th><center>OSA Charges(-)</center></th>
  <td><center><?php echo $osa_amount; ?></center></td>
  </tr> 
  <tr>
  <th><center>Other Charges(-)</center></th>
  <td><center><?php echo $other_amount; ?></center></td>
  </tr>
  <tr>
  <th><center>Net Payment</center></th>
  <th><center><?php echo number_format($net_cod - $bulk_flyer - $osa_amount - $other_amount); ?>/-</center></th>
  </tr> 
</thead>
</table>
<?php
if($remark!=""){echo("<p>*".$remark."</p>");}?>
<center><table width=100% border=1 class='m-t-10'>
 <thead>
 <tr>
  <th><center>Sr.</center></th>
  <th><center>CN</center></th>
  <th><center>Consgnee Detail</center></th>
  <th><center>COD</center></th>
  <th><center>SC</center></th>
  <th><center>GST</center></th>
  <th><center>Fuel</center></th>
  <th><center>Flyer</center></th>
  <th><center>SP Handling</center></th>
  <th><center>Cash Handling</center></th>
  <th><center>With Flyer</center></th>
  <th><center>Without Flyer</center></th>
</tr> 
</thead>
<tbody>
<?php if(!empty($sheet_data)){
foreach($sheet_data as $rows){
$i=$i+1;
echo("<tr>");
echo("<td><center>".$i."</center></td>");
echo("<td><center>".$rows->cn."</center></td>");
echo("<td><center>".$rows->consignee_detail."</center></td>");
echo("<td><center>".number_format($rows->cod)."/-</center></td>"); 
echo("<td><center>".number_format($rows->sc)."/-</center></td>");
echo("<td><center>".number_format($rows->gst,2)."/-</center></td>");
echo("<td><center>".number_format($rows->fuel,2)."/-</center></td>");
echo("<td><center>".number_format($rows->flyer)."/-</center></td>");
echo("<td><center>".number_format($rows->sp_handling,2)."/-</center></td>");
echo("<td><center>".number_format($rows->cash_handling,2)."/-</center></td>");
echo("<td><center>".number_format($rows->cod-($rows->sc+$rows->gst+$rows->cash_handling+$rows->fuel+$rows->flyer+$rows->sp_handling))."/-</center></td>");
echo("<td><center>".number_format($rows->cod-($rows->sc+$rows->gst+$rows->cash_handling+$rows->fuel+$rows->sp_handling))."/-</center></td>");
}} ?>
<tr>
<td></td>  
<td></td>  
<td></td>  
<th><center><?php echo number_format($total_cod); ?>/-</center></th>  
<th><center><?php echo number_format($total_sc); ?>/-</center></th> 
<th><center><?php echo number_format($total_gst,2); ?>/-</center></th> 
<th><center><?php echo number_format($total_fuel,2); ?>/-</center></th>  
<th><center><?php echo number_format($total_flyer); ?>/-</center></th>  
<th><center><?php echo number_format($total_sp,2); ?>/-</center></th>  
<th><center><?php echo number_format($total_cash,2); ?>/-</center></th>  
<th><center><?php echo number_format($total_cod-($total_sc+$total_gst+$total_cash+$total_fuel+$total_flyer+$total_sp)); ?>/-</center></th> 
<th><center><?php echo number_format($total_cod-($total_sc+$total_gst+$total_cash+$total_fuel+$total_sp)); ?>/-</center></th> 
</tbody>
</table>
  



</div>

</div>

</div>

</div>
         <!-- END card -->
              </div>

            </div>
            <!-- END PLACE PAGE CONTENT HERE -->
          </div>
          <!-- END CONTAINER FLUID -->
        </div>
        <!-- END PAGE CONTENT -->




</div>
 
</div>
<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Deduction <?php echo $sheet_code; ?></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <p id="msg_show">Manage Invoice Deductions.</p>
 <div class="form-group-attached" style="border-color: black">
<div class="row clearfix">
<div class="col-md-12">
<div class="form-group form-group-default required" aria-required="true" id="name_div">
<label>Deduction Name</label>
<input type="text"   class="form-control" name="name" id="name" tabindex="1">
<input type="hidden" value="<?php echo $sheet_id; ?>" name="code" id="code" >
</div>
</div>
</div>
<div class="row clearfix">
<div class="col-md-12 m-t-10">
<div class="form-group form-group-default required" id="amount_div">
<label>Deduction Amount</label>
<input type="phone" class="form-control" name="amount" id="amount" tabindex="2">
</div>
</div>
</div>
</div>
        
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" onclick="add_deduction()">Save Deduction</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div> 
<script type="text/javascript">
function add_deduction(){
var check="Pass";
var name="";
var amount="";
var code=<?php echo $sheet_id; ?>;
//------------Name
if($("#name").val()!=""){
name=$("#name").val();
$("#name_div").css("border-color", "rgba(0, 0, 0, 0.07)");  
} else {
$("#name_div").css("border-color", "red"); 
$("#name").focus();
check="Fail";
}
//--------------------------------End
//------------Amount-----------
if($("#amount").val()!="" ){
amount=$("#amount").val();
$("#amount_div").css("border-color", "rgba(0, 0, 0, 0.07)");  
} else {
$("#amount_div").css("border-color", "red");  
$("#amount").focus();
check="Fail";
}
//--------------------------------End
//-------Checking Conditions---------
if(check!="Fail"){  
var mydata={
name              :name,
amount            :amount,
code              :code
};
$.ajax({
url: "<?php echo base_url(); ?>Invoice/add_deduction",
type: "POST",
data: mydata,        
success: function(data) {
$("#msg_show").html(data);
}
});
$("#name").val("");
$("#amount").val("");
$("#name").focus("");
}
}
</script>
<?php
$this->load->view('inc/footer');
?>      