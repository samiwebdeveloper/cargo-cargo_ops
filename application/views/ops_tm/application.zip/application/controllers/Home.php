<?php


class Home extends CI_Controller {

	function __construct() {
    parent::__construct();
    $this->load->model('Qsrmodel');
    $this->load->model('Commonmodel');
	//$this->load->model('Pickmodel');
	//$this->load->model('Bookingmodel');
    }

    
	public function index(){
	//$this->Commonmodel->Seprate_Tm_Cities();    
	    
    $root = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
    if($root=="https"){ 
    //-------------PERMISSONS------------------
    if($_SESSION['user_power']!="SE" && $_SESSION['user_power']!="TM" && $_SESSION['user_power']!="TP" && $_SESSION['user_power']!="SM" && $_SESSION['user_power']!="TPT" && $_SESSION['user_power']!="RIDER" && $_SESSION['user_power']!="Accounts" && $_SESSION['user_power']!="CS"){    
   // $data['pending_data']=$this->Qsrmodel->Get_Pending_Shipments_Branch($_SESSION['origin_id']);
   // $data['incomming_pendings_count']=$this->Qsrmodel->Get_Incomming_Pendings_By_Orgin($_SESSION['origin_id']);
    //$data['pendings_dd_count']=$this->Qsrmodel->Get_Pendings_DD_By_Orgin_Count($_SESSION['origin_id']);
    //$data['pendings_pickup_count']=$this->Qsrmodel->Get_Pendings_Pickup_By_Orgin_Count($_SESSION['origin_id']);
    } else  if($_SESSION['user_power']=="SE" ) {
    $data['pending_data']=$this->Qsrmodel->Get_Pending_Shipments_admin();
    //$data['incomming_pendings_count']=$this->Qsrmodel->Get_Incomming_Pendings_By_Admin();
    //$data['pendings_dd_count']=$this->Qsrmodel->Get_Pendings_DD_By_Admin_Count();
   // $data['pendings_pickup_count']=$this->Qsrmodel->Get_Pendings_Pickup_By_Admin_Count();
    } else  if($_SESSION['user_power']=="CS" ) {
    $data['pending_data']=$this->Qsrmodel->Get_Pending_Shipments_admin();
    //$data['incomming_pendings_count']=$this->Qsrmodel->Get_Incomming_Pendings_By_Admin();
    //$data['pendings_dd_count']=$this->Qsrmodel->Get_Pendings_DD_By_Admin_Count();
   // $data['pendings_pickup_count']=$this->Qsrmodel->Get_Pendings_Pickup_By_Admin_Count();
    } else  if($_SESSION['user_power']=="TM") {
    redirect('Importfile');
    } else  if($_SESSION['user_power']=="TP") {
    redirect('Agent');
    } else if($_SESSION['user_power']=="SM"){    
   // $data['pending_data']=$this->Qsrmodel->Get_Pending_Shipments_Sale($_SESSION['user_id']);
    //$data['incomming_pendings_count']=$this->Qsrmodel->Get_Incomming_Pendings_By_Sale($_SESSION['user_id']);
   // $data['pendings_dd_count']=$this->Qsrmodel->Get_Pendings_DD_By_Sale_Count($_SESSION['user_id']);
   // $data['pendings_pickup_count']=$this->Qsrmodel->Get_Pendings_Pickup_By_Sale_Count($_SESSION['user_id']);
    } else  if($_SESSION['user_power']=="TPT") {
    redirect('Home/TPT');
    } else  if($_SESSION['user_power']=="Accounts") {
    redirect('invoice/unpaid_cn_all');
    } else  if($_SESSION['user_power']=="RIDER") {
    redirect('Delivery2');
    }
    //-------------PERMISSONS------------------	   
	$this->load->view('dashboardView',$data);	
	} else if($root=="http"){
    header('Location: https://tmdelex.com/cargo/ops_tm/Home');    
    }
	    
	}
	

	
	public function TPT(){
	$root = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
    if($root=="https"){
   // $data['pending_data']=$this->Qsrmodel->Get_TPT_Pending_Shipments($_SESSION['thrid_party_id']);
    //$data['incomming_pendings_count']="";
    //$data['pendings_dd_count']=$this->Qsrmodel->Get_Pendings_DD_By_TPT_Count($_SESSION['user_id']);
   // $data['pendings_pickup_count']=$this->Qsrmodel->Get_Pendings_Pickup_By_TPT_Count($_SESSION['thrid_party_id']);
    $this->load->view('dashboardTPTView',$data);	
    } else if($root=="http"){
    header('Location: https://tmdelex.com/cargo/ops_tm/Home');    
    }
	}
	
	public function sm(){
    $root = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
    if($root=="https"){ 
    //-------------PERMISSONS------------------
    if($_SESSION['user_power']=="SM"){    
   // $data['pending_data']=$this->Qsrmodel->Get_Pending_Shipments_Sale($_SESSION['user_id']);
    //$data['incomming_pendings_count']=$this->Qsrmodel->Get_Incomming_Pendings_By_Sale($_SESSION['user_id']);
    //$data['pendings_dd_count']=$this->Qsrmodel->Get_Pendings_DD_By_Sale_Count($_SESSION['user_id']);
    //$data['pendings_pickup_count']=$this->Qsrmodel->Get_Pendings_Pickup_By_Sale_Count($_SESSION['user_id']);
    }
    //-------------PERMISSONS------------------	   
	$this->load->view('dashboardView',$data);	
	} else if($root=="http"){
    header('Location: https://tmdelex.com/cargo/ops_tm/Home/sm');    
    }
	    
	}
	
	
	//public function branch_pending(){
//	$data['pending_data']=$this->Qsrmodel->Get_Pending_Shipments_Branch($_SESSION['origin_id']);	
//	$data['summary_pending_data']=$this->Qsrmodel->Get_Pending_Shipments_Branch_Summary($_SESSION['origin_id']);	
//	$this->load->view('module_pending/brnachpendingView',$data);	
//	}
	
	
//	public function admin_pending(){
//	$data['pending_data']=$this->Qsrmodel->Get_Pending_Shipments_Admin();	
//	$data['summary_pending_data']=$this->Qsrmodel->Get_Pending_Shipments_Admin_Summary();	
//	$this->load->view('module_pending/adminpendingView',$data);	
//	}
	
	public function branch_qsr(){
	$data['qsr_data']="";	
	$data['start_date']="";	
	$data['end_date']="";
	$data['msg']="";	
	$this->load->view('module_qsr/qsrbranchView',$data);    
	}
//-------------------Admin QSR--------------------------------------------------	
	public function admin_qsr(){
	$data['qsr_data']="";	
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	
	$data['start_date']="";	
	$data['customer_id']="";	
	$data['end_date']="";
	$data['msg']="";	
	$this->load->view('module_qsr/qsradminView',$data);    
	}
//-------------------CS QSR--------------------------------------------------	
	public function cs_qsr(){
	$data['qsr_data']="";	
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	
	$data['start_date']="";	
	$data['customer_id']="";	
	$data['end_date']="";
	$data['msg']="";	
	$this->load->view('module_qsr/qsrcsView',$data);    
	}	
//-------------------DEO QSR----------------------------------------------------	
	public function admin_qsr1(){
	$data['qsr_data']="";	
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	
	$data['start_date']="";	
	$data['customer_id']="";	
	$data['end_date']="";
	$data['msg']="";	
	$this->load->view('module_qsr/qsradmin1View',$data);    
	}
	
	public function admin_pending(){
	$data['qsr_data']="";	
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	
	$data['start_date']="";	
	$data['customer_id']="";	
	$data['end_date']="";
	$data['msg']="";	
	$this->load->view('module_qsr/qsrpendingView',$data);    
	}
//-------------------OPS QSR----------------------------------------------------	
	public function admin_opslhe(){
	$data['qsr_data']="";	
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	
	$data['start_date']="";	
	$data['customer_id']="";	
	$data['end_date']="";
	$data['msg']="";	
	$this->load->view('module_qsr/qsropslheView',$data);    
	}
	
	public function old_branch_qsr(){
	$data['qsr_data']="";	
	$data['start_date']="";	
	$data['end_date']="";
	$data['msg']="";	
	$this->load->view('module_qsr/qsroldbranchView',$data);    
	}
	
	
	public function old_admin_qsr(){
	$data['qsr_data']="";	
	$data['start_date']="";	
	$data['end_date']="";
	$data['msg']="";	
	$this->load->view('module_qsr/qsroldadminView',$data);    
	}
	
	
	public function submit_branch_qsr(){
	$data['qsr_data']="";	
	$data['start_date']="";	
	$data['end_date']="";
	$data['msg']="";		
	$start_date  = $this->input->post('start_date');
	$end_date    = $this->input->post('end_date');
	
	if($start_date!="" && $end_date!=""){
	$data['msg']="";
	$qsr_data=$this->Qsrmodel->Get_Shipments_Branch($_SESSION['origin_id'],$start_date,$end_date);	
	$qsr_archive_data=$this->Qsrmodel->Get_Shipments_Branch_Archive($_SESSION['origin_id'],$start_date,$end_date);	
	$data['qsr_data']=array_merge($qsr_data,$qsr_archive_data);
	$data['summary_qsr_data']=$this->Qsrmodel->Get_Shipments_Branch_Summary($_SESSION['origin_id'],$start_date,$end_date);	
	$data['summary_archive_qsr_data']=$this->Qsrmodel->Get_Shipments_Branch_Summary_Archive($_SESSION['origin_id'],$start_date,$end_date);	
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;		
	} else {
	$data['msg']="<p class='alert alert-danger'><strong>Something is Missing.</strong></p>";
	$data['qsr_data']="";	
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;
	}	
	$this->load->view('module_qsr/qsrbranchView',$data);	
	}
	
	
	public function submit_old_branch_qsr(){
	$data['qsr_data']="";	
	$data['start_date']="";	
	$data['end_date']="";
	$data['msg']="";		
	$start_date  = $this->input->post('start_date');
	$end_date    = $this->input->post('end_date');
	if($start_date!="" && $end_date!=""){
	$data['msg']="";
	$data['qsr_data']=$this->Qsrmodel->Get_Shipments_Branch_Old($_SESSION['origin_name'],$start_date,$end_date);	
	$data['summary_qsr_data']=$this->Qsrmodel->Get_Shipments_Branch_Summary_Old($_SESSION['origin_name'],$start_date,$end_date);	
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;		
	} else {
	$data['msg']="<p class='alert alert-danger'><strong>Something is Missing.</strong></p>";
	$data['qsr_data']="";	
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;
	}	
	$this->load->view('module_qsr/qsroldbranchView',$data);	
	}

    	
	public function submit_admin_qsr(){
	$data['qsr_data']="";	
	$data['start_date']="";	
	$data['end_date']="";
	$data['msg']="";
	$data['customer_id']="";
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	
	$start_date  = $this->input->post('start_date');
	$end_date    = $this->input->post('end_date');
	$customer    = $this->input->post('customer_id');
	if($start_date!="" && $end_date!="" && $customer!=""){
	$data['msg']="";
	if($customer==0){
	$qsr_data=$this->Qsrmodel->Get_Shipments_Admin_Tm($start_date,$end_date);
	$qsr_archive_data=$this->Qsrmodel->Get_Shipments_Admin_Archive_Tm($start_date,$end_date);
	} else {
	$qsr_data=$this->Qsrmodel->Get_Shipments_Admin_Customer_Tm($start_date,$end_date,$customer);
	$qsr_archive_data=$this->Qsrmodel->Get_Shipments_Admin_Archive_Customer_Tm($start_date,$end_date,$customer);
	}
	$data['summary_qsr_data']=$this->Qsrmodel->Get_Shipments_Admin_Summary($start_date,$end_date);	
	$data['summary_archive_qsr_data']=$this->Qsrmodel->Get_Shipments_Admin_Summary_Archive($start_date,$end_date);
	$data['qsr_data']=array_merge($qsr_data,$qsr_archive_data);
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;
	$data['customer_id']=$customer;
	} else {
	$data['msg']="<p class='alert alert-danger'><strong>Something is Missing.</strong></p>";
	$data['qsr_data']="";	
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;
	$data['customer_id']=$customer;
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	  
	}	
	$this->load->view('module_qsr/qsradminView',$data);	
	}
    
    public function submit_cs_qsr(){
	$data['qsr_data']="";	
	$data['start_date']="";	
	$data['end_date']="";
	$data['msg']="";
	$data['customer_id']="";
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	
	$start_date  = $this->input->post('start_date');
	$end_date    = $this->input->post('end_date');
	$customer    = $this->input->post('customer_id');
	if($start_date!="" && $end_date!="" && $customer!=""){
	$data['msg']="";
	if($customer==0){
	$qsr_data=$this->Qsrmodel->Get_Shipments_CS_Tm($start_date,$end_date);
	$qsr_archive_data=$this->Qsrmodel->Get_Shipments_Admin_Archive_Tm($start_date,$end_date);
	} else {
	$qsr_data=$this->Qsrmodel->Get_Shipments_CS_Customer_Tm($start_date,$end_date,$customer);
	$qsr_archive_data=$this->Qsrmodel->Get_Shipments_Admin_Archive_Customer_Tm($start_date,$end_date,$customer);
	}
	$data['summary_qsr_data']=$this->Qsrmodel->Get_Shipments_Admin_Summary($start_date,$end_date);	
	$data['summary_archive_qsr_data']=$this->Qsrmodel->Get_Shipments_Admin_Summary_Archive($start_date,$end_date);
	$data['qsr_data']=array_merge($qsr_data,$qsr_archive_data);
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;
	$data['customer_id']=$customer;
	} else {
	$data['msg']="<p class='alert alert-danger'><strong>Something is Missing.</strong></p>";
	$data['qsr_data']="";	
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;
	$data['customer_id']=$customer;
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	  
	}	
	$this->load->view('module_qsr/qsrcsView',$data);	
	}
	
    	
	public function submit_admin_qsr1(){
	$data['qsr_data']="";	
	$data['start_date']="";	
	$data['end_date']="";
	$data['msg']="";
	$data['customer_id']="";
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	
	$start_date  = $this->input->post('start_date');
	$end_date    = $this->input->post('end_date');
	$customer    = $this->input->post('customer_id');
	if($start_date!="" && $end_date!="" && $customer!=""){
	$data['msg']="";
	if($customer==0){
	$qsr_data=$this->Qsrmodel->Get_Shipments_Admin_Tm_DEO($start_date,$end_date);
	$qsr_archive_data=$this->Qsrmodel->Get_Shipments_Admin_Archive_Tm($start_date,$end_date);
	} else {
	$qsr_data=$this->Qsrmodel->Get_Shipments_Admin_Customer_Tm_DEO($start_date,$end_date,$customer);
	$qsr_archive_data=$this->Qsrmodel->Get_Shipments_Admin_Archive_Customer_Tm($start_date,$end_date,$customer);
	}
	$data['summary_qsr_data']=$this->Qsrmodel->Get_Shipments_Admin_Summary($start_date,$end_date);	
	$data['summary_archive_qsr_data']=$this->Qsrmodel->Get_Shipments_Admin_Summary_Archive($start_date,$end_date);
	$data['qsr_data']=array_merge($qsr_data,$qsr_archive_data);
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;
	$data['customer_id']=$customer;
	} else {
	$data['msg']="<p class='alert alert-danger'><strong>Something is Missing.</strong></p>";
	$data['qsr_data']="";	
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;
	$data['customer_id']=$customer;
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	  
	}	
	$this->load->view('module_qsr/qsradmin1View',$data);	
	}
	
	public function submit_pending_qsr(){
	$data['qsr_data']="";	
	$data['start_date']="";	
	$data['end_date']="";
	$data['msg']="";
	$data['customer_id']="";
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	
	$start_date  = $this->input->post('start_date');
	$end_date    = $this->input->post('end_date');
	$customer    = $this->input->post('customer_id');
	if($start_date!="" && $end_date!="" && $customer!=""){
	$data['msg']="";
	if($customer==0){
	$qsr_data=$this->Qsrmodel->Get_Shipments_Pending_Tm($start_date,$end_date);
	$qsr_archive_data=$this->Qsrmodel->Get_Shipments_Admin_Archive_Tm($start_date,$end_date);
	} else {
	$qsr_data=$this->Qsrmodel->Get_Shipments_Pending_Customer_Tm($start_date,$end_date,$customer);
	$qsr_archive_data=$this->Qsrmodel->Get_Shipments_Admin_Archive_Customer_Tm($start_date,$end_date,$customer);
	}
	$data['summary_qsr_data']=$this->Qsrmodel->Get_Shipments_Admin_Summary($start_date,$end_date);	
	$data['summary_archive_qsr_data']=$this->Qsrmodel->Get_Shipments_Admin_Summary_Archive($start_date,$end_date);
	$data['qsr_data']=array_merge($qsr_data,$qsr_archive_data);
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;
	$data['customer_id']=$customer;
	} else {
	$data['msg']="<p class='alert alert-danger'><strong>Something is Missing.</strong></p>";
	$data['qsr_data']="";	
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;
	$data['customer_id']=$customer;
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	  
	}	
	$this->load->view('module_qsr/qsrpendingView',$data);	
	}
	
	
	
		public function submit_admin_opslhe(){
	$data['qsr_data']="";	
	$data['start_date']="";	
	$data['end_date']="";
	$data['msg']="";
	$data['customer_id']="";
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	
	$start_date  = $this->input->post('start_date');
	$end_date    = $this->input->post('end_date');
	$customer    = $this->input->post('customer_id');
	if($start_date!="" && $end_date!="" && $customer!=""){
	$data['msg']="";
	if($customer==0){
	$qsr_data=$this->Qsrmodel->Get_Shipments_Admin_Tm_OPS($start_date,$end_date);
	$qsr_archive_data=$this->Qsrmodel->Get_Shipments_Admin_Archive_Tm($start_date,$end_date);
	} else {
	$qsr_data=$this->Qsrmodel->Get_Shipments_Admin_Customer_Tm_OPS($start_date,$end_date,$customer);
	$qsr_archive_data=$this->Qsrmodel->Get_Shipments_Admin_Archive_Customer_Tm($start_date,$end_date,$customer);
	}
	$data['summary_qsr_data']=$this->Qsrmodel->Get_Shipments_Admin_Summary($start_date,$end_date);	
	$data['summary_archive_qsr_data']=$this->Qsrmodel->Get_Shipments_Admin_Summary_Archive($start_date,$end_date);
	$data['qsr_data']=array_merge($qsr_data,$qsr_archive_data);
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;
	$data['customer_id']=$customer;
	} else {
	$data['msg']="<p class='alert alert-danger'><strong>Something is Missing.</strong></p>";
	$data['qsr_data']="";	
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;
	$data['customer_id']=$customer;
	$data['customer_data']=$this->Commonmodel->Get_all_record('saimtech_customer');	  
	}	
	$this->load->view('module_qsr/qsropslheView',$data);	
	}
	
	
	
	
	public function submit_old_admin_qsr(){
	$data['qsr_data']="";	
	$data['start_date']="";	
	$data['end_date']="";
	$data['msg']="";		
	$start_date  = $this->input->post('start_date');
	$end_date    = $this->input->post('end_date');
	if($start_date!="" && $end_date!=""){
	$data['msg']="";
	$data['qsr_data']=$this->Qsrmodel->Get_Shipments_Admin_Old($start_date,$end_date);
	$data['summary_qsr_data']=$this->Qsrmodel->Get_Shipments_Admin_Summary_old($start_date,$end_date);	
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;		
	} else {
	$data['msg']="<p class='alert alert-danger'><strong>Something is Missing.</strong></p>";
	$data['qsr_data']="";	
	$data['start_date']=$start_date;	
	$data['end_date']=$end_date;
	}	
	$this->load->view('module_qsr/qsroldadminView',$data);	
	}
	
	public function incoming_pending(){
	if($_SESSION['user_power']!="SE" && $_SESSION['user_power']!="SM"){    
	$data['incomming_pendings_data']=$this->Qsrmodel->Get_Incomming_Pendings_By_Orgin_detail($_SESSION['origin_id']);
	} else if($_SESSION['user_power']=="SE"){
	$data['incomming_pendings_data']=$this->Qsrmodel->Get_Incomming_Pendings_By_Admin_detail();
	} else if($_SESSION['user_power']=="SM"){
	$data['incomming_pendings_data']=$this->Qsrmodel->Get_Incomming_Pendings_By_Sale_detail($_SESSION['user_id']);
	}
	$this->load->view('module_report/incomingpendingView',$data);	   
	}
	

	
	public function pending_sheets(){
	if($_SESSION['user_power']!="SE" && $_SESSION['user_power']!="SM" && $_SESSION['user_power']!="TPT"){    
	$data['pending_sheets_data']=$this->Qsrmodel->Get_Pendings_DD_By_Orgin_detail($_SESSION['origin_id']);
	} else if($_SESSION['user_power']=="SE"){
	$data['pending_sheets_data']=$this->Qsrmodel->Get_Pendings_DD_By_Admin_detail();
	} else if($_SESSION['user_power']=="SM"){
	$data['pending_sheets_data']=$this->Qsrmodel->Get_Pendings_DD_By_Sale_detail($_SESSION['user_id']);
	}  else if($_SESSION['user_power']=="TPT"){
	$data['pending_sheets_data']=$this->Qsrmodel->Get_Pendings_DD_By_TPT_detail($_SESSION['user_id']);
	}
	$this->load->view('module_report/pendingsheetView',$data);	   
	}
	public function pending_manifest_sheet(){
	if($_SESSION['user_power']="SE" && $_SESSION['user_power']!="SM" && $_SESSION['user_power']!="TPT"){    
	$data['pending_manifest_data']=$this->Qsrmodel->Get_Pendings_Manifest_By_Orgin_detail($_SESSION['origin_id']);
	}// else if($_SESSION['user_power']=="SE"){
	//$data['pending_sheets_data']=$this->Qsrmodel->Get_Pendings_DD_By_Admin_detail();
	//} else if($_SESSION['user_power']=="SM"){
	//$data['pending_sheets_data']=$this->Qsrmodel->Get_Pendings_DD_By_Sale_detail($_SESSION['user_id']);
	//}  else if($_SESSION['user_power']=="TPT"){
	//$data['pending_sheets_data']=$this->Qsrmodel->Get_Pendings_DD_By_TPT_detail($_SESSION['user_id']);
	//}
	$this->load->view('module_report/pendingmanifestView',$data);	   
	}
	
	public function pending_pickups(){
	if($_SESSION['user_power']!="SE" && $_SESSION['user_power']!="SM" && $_SESSION['user_power']!="TPT"){        
	$data['pending_pickups_data']=$this->Qsrmodel->Get_Pendings_Pickup_By_Orgin_Detail($_SESSION['origin_id']);
	$this->load->view('module_report/pendingpickupView',$data);	 
	} else if($_SESSION['user_power']=="SE"){
	$data['pending_pickups_data']=$this->Qsrmodel->Get_Pendings_Pickup_By_Admin_Detail();
	$this->load->view('module_report/pendingpickupView',$data);	 
	} else if($_SESSION['user_power']=="SM"){
	$data['pending_sheets_data']=$this->Qsrmodel->Get_Pendings_Pickup_By_Sale_Detail($_SESSION['user_id']);
	$this->load->view('module_report/pendingpickupView',$data);	 
	} else if($_SESSION['user_power']=="TPT"){
	$data['pending_sheets']=$this->Qsrmodel->Get_Pendings_Pickup_By_TPT_Detail($_SESSION['thrid_party_id']);
	$this->load->view('module_report/pendingpickupTPTView',$data);	 
	}     
	}
	
	public function all_ok(){
	$data['title']="All Delivered Data";    
	$data['sheet_data']=$this->Qsrmodel->Get_All_Deliverd_TPT_Detail($_SESSION['thrid_party_id']);
	$this->load->view('module_report/tptView',$data);	     
	}

    public function all_rtd(){
    $data['title']="All Return To Delex Data"; 
    $data['sheet_data']=$this->Qsrmodel->Get_All_RTD_TPT_Detail($_SESSION['user_id']);
	$this->load->view('module_report/tptView',$data);	         
	}
    	
	public function mail(){
	$this->load->view('module_report/inboxView');	        
	}
	
	
	public function setting_view(){
	$data['msg']="";	
	$this->load->view('module_report/settingView',$data);		
	}

	public function submit_setting(){
	$old_password = $this->input->post('old_password');
	$new_password = $this->input->post('new_password');
	$retype_password = $this->input->post('retype_password');
	$db_password  = "";
	if($old_password!="" && $new_password!="" && $retype_password!=""){
    $db_data=$this->Commonmodel->Get_record_by_condition('saimtech_oper_user', 'oper_user_id', $_SESSION['user_id']);
    if(!empty($db_data)){foreach($db_data as $rows){$db_password=$rows->oper_user_password;}}
    if($db_password==md5($old_password)){
    if($new_password==$retype_password){
    $data = array('oper_user_password' => md5($new_password));	
    $this->Commonmodel->Update_record('saimtech_oper_user', 'oper_user_id', $_SESSION['user_id'], $data);
    $data['msg']="<p class='alert alert-success'>Your password is successfully changed.</p>";
    } else { $data['msg']="<p class='alert alert-danger'>Retype password not matched.</p>";}
    } else { $data['msg']="<p class='alert alert-danger'>Incorrect old password.</p>";}
	} else { $data['msg']="<p class='alert alert-danger'>Something is missing please try again.</p>";}	
	$this->load->view('module_report/settingView',$data);		
	}
}
